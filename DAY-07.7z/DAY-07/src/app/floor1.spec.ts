import { TestBed } from '@angular/core/testing';

import { Floor1 } from './floor1';

describe('Floor1', () => {
  let service: Floor1;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Floor1);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
