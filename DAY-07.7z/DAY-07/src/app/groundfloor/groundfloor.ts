import { Component } from '@angular/core';
import { Floor1 } from '../floor1';

@Component({
  selector: 'app-groundfloor',
  imports: [],
  templateUrl: './groundfloor.html',
  styleUrl: './groundfloor.css',
})
export class Groundfloor {
  message = '';
constructor(private groundfloor: Floor1) {}
  // 👆 AC is injected here (DI)
onAc() {
    this.message = this.groundfloor.turnOn();
  }
offAc() {
    this.message = this.groundfloor.turnOff();
  }
}

