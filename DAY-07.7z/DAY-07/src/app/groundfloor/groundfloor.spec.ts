import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Groundfloor } from './groundfloor';

describe('Groundfloor', () => {
  let component: Groundfloor;
  let fixture: ComponentFixture<Groundfloor>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Groundfloor]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Groundfloor);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
