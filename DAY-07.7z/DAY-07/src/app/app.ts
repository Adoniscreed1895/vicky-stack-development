import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Groundfloor } from "./groundfloor/groundfloor";

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Groundfloor],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('AChotel_app');
}
