package com.example.demo;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class Carcontroller {

	private Car1 car;
	public Carcontroller(Car1 car) {
		this.car=car;
	}
	@GetMapping("/drive")
	public String drivecar()
	{
		return car.drive();
	}
}
