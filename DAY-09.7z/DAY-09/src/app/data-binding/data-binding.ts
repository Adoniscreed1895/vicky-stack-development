import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-data-binding',
  imports: [FormsModule],
  templateUrl: './data-binding.html',
  styleUrl: './data-binding.css',
})
export class DataBinding {
  name= "TAMIL NADU";

// PROPERTY BINDING
 isdisabled= false;

 // event binding
 enablebutton(){
  this.isdisabled= true;
 }
// two way binding
username='';
showalert(){
  alert('hello' + this.username)
}
}
