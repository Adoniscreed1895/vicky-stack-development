import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { SubDirective } from "./sub-directive/sub-directive";
import { Structural } from "./structural/structural";

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, SubDirective, Structural],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('directive');
}
