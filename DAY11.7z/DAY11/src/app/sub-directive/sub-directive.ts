import { Component } from '@angular/core';

@Component({
  selector: 'app-sub-directive',
  imports: [],
  templateUrl: './sub-directive.html',
  styleUrl: './sub-directive.css',
})
export class SubDirective {
  name:string="maverick";
  course:string="martialarts- judo";
fees:number=999;
}
