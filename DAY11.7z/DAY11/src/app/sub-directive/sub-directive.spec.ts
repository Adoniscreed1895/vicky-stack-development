import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubDirective } from './sub-directive';

describe('SubDirective', () => {
  let component: SubDirective;
  let fixture: ComponentFixture<SubDirective>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SubDirective]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SubDirective);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
