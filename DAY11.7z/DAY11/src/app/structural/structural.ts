import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-structural',
  imports: [CommonModule],
  templateUrl: './structural.html',
  styleUrl: './structural.css',
})
export class Structural  {

  
  // ====== ngIf ======
  isLoggedIn: boolean = false;

  // ====== ngFor ======
  courses: string[] = ['Angular', 'React', 'Vue', 'Node'];

  // ====== ngSwitch ======
  role: string = 'admin';

  // ====== Methods ======
  login() {
    this.isLoggedIn = true;
  }

  logout() {
    this.isLoggedIn = false;
  }

  setRole(newRole: string) {
    this.role = newRole;
  }
}
