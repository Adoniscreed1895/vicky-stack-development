package demo;

public class child {
	  int b=8;
		   void m2(int b) 
		   {
			   System.out.println("hello "+b);
			   System.out.println("hello "+this.b);
		//	   System.out.println("hello "+a);
		   }
	public static void main(String[] args) {
		child  xy = new child();
		xy.m2(3);
	}
	}