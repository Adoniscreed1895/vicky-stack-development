package abc;

 class child {

		private	int a;
			
		public int getA() {
			return a;
		}

		public void setA(int a) {
			this.a = a;
		}

			
		}
		public class Abcs extends child {

		public static void main(String[] args) {
			Abcs  xy = new Abcs();
		    xy.setA(22);
		    System.out.println(xy.getA());
			
		}
		}