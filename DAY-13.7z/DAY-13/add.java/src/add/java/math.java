package add.java;

public class math {
	 void main () {
		System.out.println( (3+3));
		System.out.println( (3-3));
		System.out.println( (3*3));
		System.out.println( (9/3));
	 } 

	public static void main(String[] args) {
		math ff = new math();
		
ff.main();

	}

}
