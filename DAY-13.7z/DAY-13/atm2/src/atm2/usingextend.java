package atm2;
abstract class ATM {
	abstract void withdraw();

	abstract void deposite();
}

abstract class Abcd extends ATM {

	@Override
	void withdraw() {
		System.out.println("asdfasdf");
	}

}


public class usingextend extends Abcd {
	@Override
	void deposite() {

		System.out.println("ahello wrld");
	}


	public static void main(String[] args) {
		usingextend xy = new usingextend();
		xy.withdraw();
		xy.deposite();

	}

}
