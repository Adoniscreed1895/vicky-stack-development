package atm;
abstract class ATM {
	abstract void withdraw();

	abstract void deposite();

}


public class usingabstract extends ATM {

	void withdraw() {
		System.out.println("misnisnfoasndfoasodfnasodf");
	}

	void deposite() {
		System.out.println("sdfoasdfoasjfoasjdfoasodfaosjfoas");
	}

		
	public static void main(String[] args) {
		usingabstract xy = new usingabstract();
xy.withdraw();
xy.deposite();
	}

	}

