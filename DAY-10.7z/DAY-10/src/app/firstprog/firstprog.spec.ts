import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Firstprog } from './firstprog';

describe('Firstprog', () => {
  let component: Firstprog;
  let fixture: ComponentFixture<Firstprog>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Firstprog]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Firstprog);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
