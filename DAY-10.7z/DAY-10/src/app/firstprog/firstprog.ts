import { Component } from '@angular/core';

@Component({
  selector: 'app-firstprog',
  imports: [],
  templateUrl: './firstprog.html',
  styleUrl: './firstprog.css',
})
export class Firstprog {

}
