import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Firstprog } from "./firstprog/firstprog";

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Firstprog],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('developer vicky');
  message = 'this my first programme in angula';

  changeMessage() {
    this.message = 'Button Clicked!';
  }
 
}