import { Routes } from '@angular/router';
import { Home } from './home/home';
import { Login } from './login/login';
import { DashboardComponent } from './dashboard/dashboard';
import { authGuard } from './authguard-guard';

export const routes: Routes = [
  { path: '', component: Home },
  { path: 'login', component: Login },
  {
    path: 'dashboard',
    component: DashboardComponent,
    canActivate: [authGuard]   // 🔐 protected
  }
];
