import { Component } from '@angular/core';
import { CommonModule } from '@angular/common'; // This gives you *ngFor and date pipe
import { FormsModule } from '@angular/forms';

interface Message {
  text: string;
  sender: 'user' | 'bot';
  time: Date;
}

@Component({
  selector: 'app-chatbox',
  standalone: true,
  imports: [CommonModule, FormsModule], // Adding CommonModule fixes the pipe error
  templateUrl: './chatbox.html',
  styleUrls: ['./chatbox.css']
})
export class Chatbox {
  newMessage: string = '';
  messages: Message[] = [
    { text: 'Hello!', sender: 'bot', time: new Date() }
  ];

  sendMessage() {
    if (this.newMessage.trim()) {
      this.messages.push({
        text: this.newMessage,
        sender: 'user',
        time: new Date()
      });
      this.newMessage = '';
    }
  }
}