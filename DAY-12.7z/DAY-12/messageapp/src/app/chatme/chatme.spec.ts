import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Chatme } from './chatme';

describe('Chatme', () => {
  let component: Chatme;
  let fixture: ComponentFixture<Chatme>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Chatme]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Chatme);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
