import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './chatme.html',
  styleUrls: ['./chatme.css']
})
export class ProfileComponent {
  agentName = 'Gemini Assistant';
  status = 'Online';
  avatarUrl = 'https://api.dicebear.com/7.x/bottts/svg?seed=Gemini'; // Dynamic avatar
}
