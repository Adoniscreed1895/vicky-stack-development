import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Chatbox } from "./chatbox/chatbox";
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Chatbox],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('messageapp');
}
