function  validateform() {
    var username= document.getElementById("username").value;
    var password= document.getElementById("password").value;


if (username ==""){
    alert("user name should not be empty")
    return false;
}

if (password==""){
    alert("password should not be empty")
    return false;
}
if (username =="vicky" && password=="0123456789"){
    alert("user name is correct")
    window.location.href="index.html";
    return false;

}
}

