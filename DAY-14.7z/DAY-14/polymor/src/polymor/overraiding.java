package polymor;

public class overraiding {

	void m1()
	{
		System.out.println("method m1");
	}
	void m1(int a)
	{
		System.out.println("method m1");
	}
public static void main(String[] args) {
	overraiding  xy = new overraiding();
   xy.m1();
	
}
}