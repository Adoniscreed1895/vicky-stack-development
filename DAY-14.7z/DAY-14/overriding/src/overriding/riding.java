package overriding;



abstract class child {

	 abstract  void m1() ;
}
public class riding extends child {
	void m1()
	{
		System.out.println("method m1");
	}

public static void main(String[] args) {
	riding  xy = new riding();
   xy.m1();

	
}
}
