package overloading;
class Abcd
{
	void m1()
	{
		System.out.println("method m1 fsdasdfsdfaro paarent clas");
	}
}
public class loading {

	public static void main(String[] args) {
		Abcd  xy = new Abcd();
		xy.m1();

			
		}
		}

//method overloading/ method overriding

//same name of the method with  diffi in same class	
//same nan of  a method with same parameter in ssub classs



